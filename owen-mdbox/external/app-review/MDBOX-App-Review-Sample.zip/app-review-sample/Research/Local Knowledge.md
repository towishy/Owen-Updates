---
title: "Local Knowledge"
type: research
tags: [app-review, research, local-first]
created: 2026-08-17
---

# Local Knowledge

## Local-first principles

The selected folder remains the canonical source. MDBOX does not require an account or upload document contents to a publisher-operated server.[^privacy]

The review path begins at [[Workspace Overview]] and continues to [[Projects/Launch Plan#Tasks|the project tasks]]. The key completion block is [[Projects/Launch Plan#^review-milestone]].

## Search model

For a document set $D$, a simple relevance score can combine title, body, and tag matches:

$$
score(d) = 3T_d + 2B_d + G_d, \quad d \in D
$$

> [!SUMMARY] Expected result
> Searching for `local-first` should return this note and expose its matching context.

[^privacy]: Search indexes, revisions, OCR output, and backups remain on the Mac.
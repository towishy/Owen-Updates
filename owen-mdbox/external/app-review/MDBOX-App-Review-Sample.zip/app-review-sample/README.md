---
title: "MDBOX App Review Sample"
tags: [app-review, sample]
---

# MDBOX App Review Sample

This folder contains non-sensitive Markdown files created for App Review. Open the folder itself in MDBOX. No account, login, network connection, or additional setup is required.

Start with [[Workspace Overview]], then follow the links to [[Projects/Launch Plan]] and [[Research/Local Knowledge]].

The sample demonstrates:

- Markdown editing, Live Preview, Reader, YAML Properties, and autosave
- Title, content, tag, and folder search
- WikiLinks, heading links, block links, backlinks, and the knowledge graph
- Task Hub items, tables, callouts, math, footnotes, and Mermaid diagrams
- Document comparison, revision recovery, and HTML/PDF export

The files may be edited, renamed, moved, or deleted during review.
---
title: "Workspace Overview"
type: dashboard
tags: [app-review, workspace, planning]
created: 2026-08-17
---

# Workspace Overview

MDBOX keeps this folder as the source of truth. Continue with [[Projects/Launch Plan|the launch plan]] or review [[Research/Local Knowledge#Local-first principles|the research notes]].

> [!NOTE] App Review workflow
> Use Search for `local-first`, open Task Hub, inspect the knowledge graph, edit a task, and export this page as HTML or PDF.

## Current work

- [x] Prepare a sample workspace
- [ ] Review the linked research note
- [ ] Export the launch plan to PDF

## Workspace flow

```mermaid
flowchart LR
  Capture[Capture notes] --> Connect[Connect ideas]
  Connect --> Review[Review tasks]
  Review --> Export[Export results]
```

| Area | Sample document | Status |
| --- | --- | --- |
| Planning | [[Projects/Launch Plan]] | In progress |
| Research | [[Research/Local Knowledge]] | Ready |